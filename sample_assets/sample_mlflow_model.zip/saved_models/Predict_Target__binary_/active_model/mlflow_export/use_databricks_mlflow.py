# ============================================================
# USE DATAIKU MLFLOW EXPORT IN DATABRICKS
# ============================================================
#
# Dataiku DSS 14 MLflow exports require MLflow >= 2.17.2.
# The exported MLflow model contains its own environment requirement files.

import os
import zipfile
import mlflow
import dataikuscoring.mlflow

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
EXPORT_ZIP = os.path.join(BASE_DIR, "scoring_mlflow.zip")
EXTRACT_DIR = os.path.join(BASE_DIR, "extracted")

os.makedirs(EXTRACT_DIR, exist_ok=True)
if not os.listdir(EXTRACT_DIR):
    with zipfile.ZipFile(EXPORT_ZIP, "r") as z:
        z.extractall(EXTRACT_DIR)

model_dir = None
for root, dirs, files in os.walk(EXTRACT_DIR):
    if "MLmodel" in files:
        model_dir = root
        break

if model_dir is None:
    raise FileNotFoundError("MLmodel was not found inside the Dataiku MLflow export.")

# Generic MLflow scoring
pyfunc_model = mlflow.pyfunc.load_model(model_dir)
# pyfunc_predictions = pyfunc_model.predict(scoring_df)

# Dataiku DSS flavor - preferred for parity and direct predict_proba()
dss_model = dataikuscoring.mlflow.load_model(model_dir)
# predictions = dss_model.predict(scoring_df)
# probabilities = dss_model.predict_proba(scoring_df)  # classification only

# OPTIONAL: register after parity validation
# REGISTERED_MODEL_NAME = "<catalog>.<schema>.<model_name>"
# mlflow.set_registry_uri("databricks-uc")
# with mlflow.start_run() as run:
#     dataikuscoring.mlflow.log_model(dss_model, artifact_path="model")
#     model_uri = f"runs:/{run.info.run_id}/model"
# registered = mlflow.register_model(model_uri=model_uri, name=REGISTERED_MODEL_NAME)
# print(registered)
